//
//  collective.cpp
//  Implementation of a collective
//
//  Created by jarico on 21/4/16.
//  Copyright © 2016 Juan A. Rico. All rights reserved.
//

#include "collective.hpp"


Collective::Collective  () {
    
}


Collective::~Collective () {
    
}
